import androidx.fragment.app.Fragment;

public class MainFragment extends Fragment {
}
