import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {
}
