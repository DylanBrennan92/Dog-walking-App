package com.example.registeractivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RegisterAccountActivity extends AppCompatActivity {
    EditText mTextFullName;
    EditText mTextPassword;
    Button mButtonRegister;
    TextView mTextViewLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_account);

        mTextFullName = (EditText)findViewById(R.id.edittext_FullName);
        mTextPassword = (EditText)findViewById(R.id.edittext_password);
        mButtonRegister= (Button)findViewById(R.id.button_register);
        mTextViewLogin = (TextView) findViewById(R.id.textview_login);

        mTextViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(RegisterAccountActivity.this,MainActivity.class);
                startActivity(LoginIntent);

            }
        });



        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mTextFullName.length() == 0) {
                    mTextFullName.setError("Please Enter Your Name");
                } else if (mTextPassword.length() == 0) {
                    mTextPassword.setError("Please Enter Your Password");
                }

            }


        });



    }
}
